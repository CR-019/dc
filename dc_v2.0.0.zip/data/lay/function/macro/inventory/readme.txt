搜索玩家背包并替换特定物品
使用方法：首先初始化，将需要检测的nbt路径和对物品执行的函数设置到lay Inventory标签下的target和func路径下。
最后执行function lay:macro/inventory/start函数。

ps:相关的函数对lay Inventory.Item进行操作